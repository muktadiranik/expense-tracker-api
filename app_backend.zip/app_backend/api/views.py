from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from .models import ToDoList
from .serializer import ToDoListSerializer


class ToDoListViewSet(ModelViewSet):
    serializer_class = ToDoListSerializer
    queryset = ToDoList.objects.all()
